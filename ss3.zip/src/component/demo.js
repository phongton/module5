let c = 7;
let b = 8;
function sum(d, b) {
    console.log(d+b)
}

sum(c,b)